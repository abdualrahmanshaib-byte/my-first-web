module.exports = (db) => {
    const router = require('express').Router();
    
    const requireAuth = (req, res, next) => {
        if (req.session.userId) next();
        else res.redirect('/auth/login');
    };

    router.use(requireAuth);

    // Question Bank Routes
    router.get('/questions', (req, res) => {
        const questions = db.prepare('SELECT * FROM questions WHERE user_id = ?').all(req.session.userId);
        res.render('questions', { questions });
    });

    router.post('/questions', (req, res) => {
        const { type, content, options } = req.body;
        db.prepare('INSERT INTO questions (user_id, type, content, options) VALUES (?, ?, ?, ?)').run(
            req.session.userId, type, content, options || null
        );
        res.json({ success: true });
    });

    // Create Exam Routes
    router.get('/create', (req, res) => {
        const questions = db.prepare('SELECT * FROM questions WHERE user_id = ?').all(req.session.userId);
        res.render('create_exam', { questions });
    });

    router.post('/create', (req, res) => {
        const { title, header_data, footer_text, questions_list } = req.body;
        const result = db.prepare('INSERT INTO exams (user_id, title, header_data, footer_text, questions_list) VALUES (?, ?, ?, ?, ?)').run(
            req.session.userId, title, JSON.stringify(header_data), footer_text, JSON.stringify(questions_list)
        );
        res.json({ success: true, examId: result.lastInsertRowid });
    });

    // View Exam for Print
    router.get('/view/:id', (req, res) => {
        const exam = db.prepare('SELECT * FROM exams WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
        if (!exam) return res.status(404).send('الاختبار غير موجود');
        
        exam.header_data = JSON.parse(exam.header_data);
        const questionIds = JSON.parse(exam.questions_list);
        const placeholders = questionIds.map(() => '?').join(',');
        const questions = db.prepare(`SELECT * FROM questions WHERE id IN (${placeholders})`).all(questionIds);
        
        res.render('view_exam', { exam, questions });
    });

    // PDF Export placeholder (using frontend printing)
    router.get('/pdf/:id', (req, res) => {
        res.redirect(`/exam/view/${req.params.id}?print=true`);
    });

    return router;
};