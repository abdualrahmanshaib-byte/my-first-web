module.exports = (db) => {
    const router = require('express').Router();
    
    // Middleware to check auth
    const requireAuth = (req, res, next) => {
        if (req.session.userId) {
            next();
        } else {
            res.redirect('/auth/login');
        }
    };

    router.get('/', (req, res) => {
        if (req.session.userId) {
            res.redirect('/dashboard');
        } else {
            res.render('home');
        }
    });

    router.get('/dashboard', requireAuth, (req, res) => {
        const user = db.prepare('SELECT username FROM users WHERE id = ?').get(req.session.userId);
        res.render('dashboard', { user });
    });

    return router;
};