module.exports = (db) => {
    const router = require('express').Router();
    const bcrypt = require('bcryptjs');

    router.get('/login', (req, res) => {
        res.render('login', { error: null });
    });

    router.post('/login', (req, res) => {
        const { username, password } = req.body;
        const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);

        if (user && bcrypt.compareSync(password, user.password)) {
            req.session.userId = user.id;
            res.redirect('/dashboard');
        } else {
            res.render('login', { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
        }
    });

    router.get('/register', (req, res) => {
        res.render('register', { error: null });
    });

    router.post('/register', (req, res) => {
        const { username, password } = req.body;
        
        try {
            const hashedPassword = bcrypt.hashSync(password, 10);
            db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(username, hashedPassword);
            res.redirect('/auth/login');
        } catch (err) {
            res.render('register', { error: 'اسم المستخدم موجود مسبقاً' });
        }
    });

    router.get('/logout', (req, res) => {
        req.session.destroy();
        res.redirect('/');
    });

    return router;
};