const express = require('express');
const session = require('express-session');
const path = require('path');
const sqlite = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const app = express();
const port = process.env.PORT || 3000;

// Setup database
const db = new sqlite(path.join(__dirname, 'database.db'));

// Database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
  );
  
  CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL, -- 'essay' or 'mcq'
    content TEXT NOT NULL,
    options TEXT, -- JSON string for MCQ options
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    header_data TEXT NOT NULL, -- JSON string for header info
    footer_text TEXT,
    questions_list TEXT NOT NULL, -- JSON string of question IDs
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

app.use(session({
  secret: 'math-exam-arabic-secret',
  resave: false,
  saveUninitialized: false
}));

// Routes
app.use('/', require('./routes/index')(db));
app.use('/auth', require('./routes/auth')(db));
app.use('/exam', require('./routes/exam')(db));

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
